var app = angular.module('myApp', []);
app.controller('myCtrl', function ($scope, $http) {
    $scope.userName = localStorage.getItem("userName");
    $scope.currentUserDetails = localStorage.getItem("userDetails");
    $scope.currentUserDetails = JSON.parse($scope.currentUserDetails);
    var URL = "https://fir-1c7de-default-rtdb.firebaseio.com/mcqAnswer";
    $scope.examDetails = {};
    $scope.questionDetails = {};
    $scope.onload = function () {
        $scope.answerList = [];
        $("#addQuestionDiv").hide();
        $("#attendExamDivId").hide();
        $("#addExamDiv").hide();
        if ($scope.userName == 'ADMIN') {
            $("#addExamDiv").show();
        } else {
            $("#attendExamDivId").show();
            getQuestionData();
            getExamData();
        }
        $scope.viewQuestionList = [];
    }
    //Exam
    $scope.addExam = function () {
        delete $scope.examDetails["$$hashKey"]
        $.ajax({
            type: 'post',
            contentType: "application/json",
            dataType: 'json',
            cache: false,
            url: URL + "/examDetails.json",
            data: JSON.stringify($scope.examDetails),
            success: function (response) {
                $scope.examDetails = {};
                alert("Exam Details Added!!!");
                $scope.$apply();
            }, error: function (error) {
                alert("Something went wrong");
            }
        });
    }
    function getExamData() {
        $scope.viewExamData = [];
        $.ajax({
            type: 'get',
            contentType: "application/json",
            dataType: 'json',
            cache: false,
            url: URL + "/examDetails.json",
            success: function (response) {
                $scope.viewExamData = [];
                let currentDate = new Date();
                for (let i in response) {
                    let data = response[i];
                    data["examDataId"] = i;
                    if (currentDate <= new Date(data.examDeadline)) {
                        $scope.viewExamData.push(data);
                    }
                }
                $scope.$apply();
            }, error: function (error) {
                alert("Something went wrong");
            }
        });
    }
    //Question
    $scope.addQuestions = function () {
        delete $scope.questionDetails["$$hashKey"];
        delete $scope.questionDetails.examName["$$hashKey"];
        $.ajax({
            type: 'post',
            contentType: "application/json",
            dataType: 'json',
            cache: false,
            url: URL + "/questionsList.json",
            data: JSON.stringify($scope.questionDetails),
            success: function (response) {
                $scope.questionDetails = {};
                alert("Question Added!!!");
                $scope.$apply();
            }, error: function (error) {
                alert("Something went wrong");
            }
        });
    }
    function getQuestionData() {
        $scope.viewQuestionData = [];
        $.ajax({
            type: 'get',
            contentType: "application/json",
            dataType: 'json',
            cache: false,
            url: URL + "/questionsList.json",
            success: function (response) {
                $scope.viewQuestionData = [];
                for (let i in response) {
                    let data = response[i];
                    data["questionId"] = i;
                    $scope.viewQuestionData.push(data);
                }
                $scope.$apply();
            }, error: function (error) {
                alert("Something went wrong");
            }
        });
    }
    $scope.onExamNameChange = function () {
        $scope.viewQuestionList = $scope.viewQuestionData.filter(function (obj) {
            return obj.examName.examName === $scope.selectExamNameModel.examName;
        })
    }
    //answer submit
    $scope.submitAnswers = function () {

        let count = 0;
        $scope.viewQuestionList.forEach(function (obj, index) {
            if (obj.ansOptionNumber.toString() === $("input[name='" + index + "_answerRadio']:checked").val()) {
                count = count + 1;
            }
        });
        const totalPercetage = (count / $scope.viewQuestionList.length) * 100;

        $scope.viewExamResultData = [];
        $.ajax({
            type: 'get',
            contentType: "application/json",
            dataType: 'json',
            cache: false,
            url: URL + "/examResult.json",
            success: function (response) {
                $scope.viewExamResultData = [];
                for (let i in response) {
                    let data = response[i];
                    data["examReultId"] = i;
                    $scope.viewExamResultData.push(data);

                }
                submitAnswer(totalPercetage);
                $scope.$apply();
            }, error: function (error) {
                alert("Something went wrong");
            }
        });


    }
    function submitAnswer(totalPercetage) {
        let data = $scope.viewExamResultData.find(function (obj) {
            return obj.examDetails.examDataId === $scope.selectExamNameModel.examDataId
                && obj.studentDetails.userId === $scope.currentUserDetails.userId;
        })
        let url, method;
        if (data == "" || data == undefined) {
            url = URL + "/examResult.json";
            method = "post";
        } else {
            url = URL + "/examResult/" + data.examReultId + ".json";
            method = "patch";
        }
        delete $scope.selectExamNameModel['$$hashKey'];
        var requestBody = {
            "studentDetails": $scope.currentUserDetails,
            "examDate": new Date(),
            "percetage": Math.round(totalPercetage),
            "examDetails": $scope.selectExamNameModel,
        }
        $.ajax({
            type: method,
            contentType: "application/json",
            dataType: 'json',
            cache: false,
            url: url,
            data: JSON.stringify(requestBody),
            success: function (response) {
                $scope.questionDetails = {};
                alert("You have scored " + Math.round(totalPercetage) + "%. Data Submitted Sucessfully!!!");
                $scope.$apply();
            }, error: function (error) {
                alert("Something went wrong");
            }
        });
    }
    $scope.logout = function () {
        localStorage.removeItem("userId");
        localStorage.removeItem("userData");
        localStorage.clear();
        window.location.href = "login.html";
    }
    $scope.switchMenu = function (type, id) {
        $(".menuCls").removeClass("active");
        $('#' + id).addClass("active");
        $("#addExamDiv").hide();
        $("#addQuestionDiv").hide();
        $("#attendExamDivId").hide()

        if (type == "ADD_EXAM") {
            $("#addExamDiv").show();
        } else if (type == "ADD_QUESTION") {
            getExamData();
            $("#addQuestionDiv").show();
        } else if (type == "ATTEND_EXAM") {
            $("#attendExamDivId").show();
            getQuestionData();
            getExamData();
        }
    }
});
