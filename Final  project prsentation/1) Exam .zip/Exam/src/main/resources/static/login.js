var URL = "https://fir-1c7de-default-rtdb.firebaseio.com/mcqAnswer";
var app = angular.module('myApp', []);
app.controller('myCtrl', function ($scope, $http) {
    getExamResult();
    function checkIsNull(value) {
        return value === "" || value === undefined || value === null ? true : false;
    }
    let adminUser = "admin@gmail.com";
    let adminPassword = "Admin@1234";
    $scope.loginUser = function () {
        let requestBody = {
            "emailId": $("#emailId").val(),
            "password": $("#pwdId").val()
        }
        if (checkIsNull($("#emailId").val()) || checkIsNull($("#pwdId").val())) {
            alert("Please fill Required Data");
        } else if (requestBody.emailId.trim() === adminUser && requestBody.password === adminPassword) {
            localStorage.setItem("userName", "ADMIN");
            window.location.href = "mcq.html";
        } else {
            $.ajax({
                type: 'get',
                contentType: "application/json",
                dataType: 'json',
                cache: false,
                url: URL + "/studentList.json",
                data: JSON.stringify(requestBody),
                success: function (lresponse) {
                    let loginUserList = [];
                    for (let i in lresponse) {
                        let data = lresponse[i];
                        data["userId"] = i;
                        loginUserList.push(data);
                    }
                    let isValid = false;
                    for (let i = 0; i < loginUserList.length; i++) {
                        if (loginUserList[i].emailId == $("#emailId").val() && loginUserList[i].password == $("#pwdId").val()) {
                            isValid = true;
                            localStorage.setItem("userDetails", JSON.stringify(loginUserList[i]));
                            localStorage.setItem("userName", "STUDENT");
                            window.location.href = "mcq.html";

                        }
                    }
                    if (!isValid) {
                        alert("User not found");
                    }
                }, error: function (error) {
                    alert("Something went wrong");
                }
            });
        }
    }
    $scope.registerUser = function () {
        if (checkIsNull($("#userNameId").val()) || checkIsNull($("#dobId").val()) || checkIsNull($("#userEmailId").val())
            || checkIsNull($("#passwordId").val()) || checkIsNull($("#contactId").val())
            || checkIsNull($("input[name='genderRadio']:checked").val())) {
            alert("Please fill all the required data");
        } else {
            let requestBody = {
                "userName": $("#userNameId").val(),
                "dob": $("#dobId").val(),
                "emailId": $("#userEmailId").val(),
                "password": $("#passwordId").val(),
                "contactNum": $("#contactId").val(),
                "gender": $("input[name='genderRadio']:checked").val(),
            }
            $.ajax({
                type: 'post',
                contentType: "application/json",
                dataType: 'json',
                cache: false,
                cache: false,
                url: URL + "/studentList.json",
                data: JSON.stringify(requestBody),
                success: function (lresponse) {
                    $('#regModelId').modal('hide');
                    alert("Registerd sucessfully!!!");
                }, error: function (error) {
                    alert("Something went wrong");
                }
            });
        }
    }
    function getExamResult() {
        $scope.viewExamData = [];
        $.ajax({
            type: 'get',
            contentType: "application/json",
            dataType: 'json',
            cache: false,
            url: URL + "/examResult.json",
            success: function (response) {
                $scope.viewExamData = [];
                for (let i in response) {
                    let data = response[i];
                    data["examDataId"] = i;
                    $scope.viewExamData.push(data);
                }
                $scope.$apply();
            }, error: function (error) {
                alert("Something went wrong");
            }
        });
    }
    $scope.resetData = function () {
        $("#userNameId").val("");
        $("#dobId").val("");
        $("#userEmailId").val("");
        $("#passwordId").val("");
        $("#contactId").val("");
        $("input[type=radio][name=genderRadio]").prop("checked", false);

    }
    $(document).ready(function () {
        $('#regModelId').on('hidden.bs.modal', function (e) {
            $scope.resetData();
        })
    });
});
